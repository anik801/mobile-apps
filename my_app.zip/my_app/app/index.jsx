import { StyleSheet, Text, View } from "react-native";
import { Link } from "expo-router";

const Home = () => {
  return (
    <View style={styles.container}>

      <View style={styles.linkContainer}>
        <Link href="/login" style={styles.linkTexts}>
          <Text>Login</Text>
        </Link>
        <Link href="/register" style={styles.linkTexts}>
          <Text>Register</Text>
        </Link>
        <Link href="/profile" style={styles.linkTexts}>
          <Text>Profile</Text>
        </Link>

      </View>
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 48,
    fontWeight: "bold",
  },
  logoTile: {
    width: 200,
    height: 200,
    marginVertical: 50,
    borderRadius: 20,
  },
  linkContainer: {
    marginTop: 50,
    alignItems: "center",
  },
  linkTexts: {
    fontSize: 20,
    borderBottomWidth: 2,
  },
});