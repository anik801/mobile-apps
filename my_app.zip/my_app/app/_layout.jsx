import { View, Text } from "react-native";
import React from "react";
import { UserProvider } from "../contexts/UserContext";
import { BooksProvider } from "../contexts/BooksContext";
import { Stack } from "expo-router";

const _layout = () => {
  return (
    <UserProvider>
      <BooksProvider>
        <Stack></Stack>
      </BooksProvider>
    </UserProvider>
  );
};

export default _layout;
